{ "tid" : "t04_flow","tdescHeader" : "Template 4:  Multiple SCOs with Assets", "tdesc" : "Template 4 shows two SCOs in a root aggregation.  In this example, the SCOs must be completed in order." }
                   
