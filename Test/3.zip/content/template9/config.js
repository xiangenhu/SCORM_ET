{ "tid" : "t09","tdescHeader" : "Template 9:  Basic Three-Way Branching","tdesc":"Template 9 shows how you can use simple sequencing rules to accomplish basic adaptive inter-SCO sequencing that is similar to the branching you might have used in traditional CBT lessons.  Based upon the learner’s choice or decision, represented as a normalized score between –1 and +1, the learner would be directed to another SCO.  " }

                   
