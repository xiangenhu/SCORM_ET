{ "tid" : "t04_choice","tdescHeader" : "Template 4:  Multiple SCOs with Assets","tdesc" : "Template 4 shows two SCOs in a root aggregation.  In this example, the SCOs can be completed in any order." }
                   
