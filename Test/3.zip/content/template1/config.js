{ "tid" : "t01","tdescHeader" : "Template 1:  Single SCO","tdesc" : "This is the most basic SCO structure.  A root aggregation contains a single SCO.  The SCO may be any size and have any amount of intra-SCO branching or an assessment.  This SCO contains one asset."}
                   
